package com.example.smartmoneyrecognition.data_class

data class rvData(
    val image: Int,
    val title: String
)
